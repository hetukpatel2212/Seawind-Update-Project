
<?php  
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Register Page</title>
</head>

<body>

    <?php 
    include 'db.php';
if(isset($_POST['submit'])){
$name = mysqli_real_escape_string($con, $_POST['name']);
$email = mysqli_real_escape_string($con, $_POST['email']);
$phone = mysqli_real_escape_string($con, $_POST['phone']);
$password = mysqli_real_escape_string($con, $_POST['password']);
$cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

$pass = password_hash($password, PASSWORD_BCRYPT);
$cpass = password_hash($cpassword, PASSWORD_BCRYPT);

$emailQuery = "select * from userregister where email = '$email'";
$query = mysqli_query($con, $emailQuery);

$emailCount = mysqli_num_rows($query);

if($emailCount>0){
    ?>
    <script>
    alert("Email already exits!");
            </script>
            <?php
}else{
    if($password === $cpassword){
$insertquery = "insert into userregister (name, email, phone, password, cpassword) value('$name', '$email', '$phone', '$pass', '$cpass')";
$iquery = mysqli_query($con, $insertquery);

if($iquery){
    ?>
    <script>
window.location = 'index.php';
        </script>
        <?php
}else{
    ?>
    <script>
    alert("Account is not created successfully");
            </script>
            <?php
}


}else{
    ?>
    <script>
    alert("Password are not matching");
            </script>
            <?php
    }
}
}
    ?>
    <form action="" method="POST">
        <div class="login">
            <h2>Register Page</h2>
            <div class="loginDetails">
                <div class="input userName">
                    <label for="">Name</label>
                    <input type="text" name="name" placeholder="Enter Your Name" required>
                </div>
                <div class="input userName">
                    <label for="">Email</label>
                    <input type="text" name="email" placeholder="Enter Your Email" required>
                </div>
                <div class="input userName">
                    <label for="">Phone Number</label>
                    <input type="text" name="phone" placeholder="Enter Your Phone Number" required>
                </div>
                <div class="input userName">
                    <label for="">Password</label>
                    <input type="password" name="password" placeholder="Enter The Password" required>
                </div>
                <div class="input userName">
                    <label for="">Confrim Password</label>
                    <input type="text" name="cpassword" placeholder="Enter The Confirm Password" required>
                </div>
                <small>Have an account ? <a href="login.php">Login In</a></small>

                <div class="loginBtn">
                    <button href="" type="submit" name="submit">Create Account</button>
                </div>
            </div>
        </div>
    </form>
</body>

</html>
