<?php
session_start();
   ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--- Material Icons CDN-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="styless.css">
    <title>Seawind</title>
</head>

<body>
    <nav>
        <div class="navBar">
            <div class="navLogo">
                <a href="">
                    <img src="images/logo.png" alt="">
                </a>
            </div>
            <div class="navBarMenu">
                <div class="menu">
                    <a href="" style="color: crimson;">Home</a>
                    <a href="">Model</a>
                    <a href="">Register As a Model</a>
                    <a href="">Hire As a Model</a>
                    <a href="">Services</a>
                    <a href="">About us</a>
                    <a href="">Contact Us</a>
                </div>
                <div class="navBtn">
                    <?php if(isset($_SESSION['name'])){
                        echo '<a href="logout.php" class="login"><span class="material-symbols-sharp">
                        login
                        </span><span>Logout</span></a>';
                    }else{
                       echo' <a href="login.php" class="login"><span class="material-symbols-sharp">
                       login
                       </span><span>Login</span></a>
                       <a href="" class="register"><span class="material-symbols-sharp">
                        edit_square
                        </span><span><a href="register.php">Register</a></span></a>';
                    }
                    ?>
                    
                </div>
                <div class=" navBtnMobile">
                    <div class="mobile">
                        <a href=""><span class="material-symbols-sharp">
                            menu
                            </span></a>
                    </div>
                </div>
            </div>
        </div>

    </nav>


    <main>
        <div class="modelImg">
            <a href="">
                <img src="images/m2.jpg" alt="">
            </a>
        </div>
        <div class="title">
            <h2>Populer Models</h2>
        </div>
        <div class="allModelImg">
            <div class="profileImg">
                <div class="images">
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m1.jpg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m3.jpg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m4.jpg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m5.jpg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m6.jpg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m7.jpg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m8.jpg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m9.jpg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m10.jpeg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m11.jpeg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m12.jpeg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m13.jpeg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m14.jpeg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m15.jpeg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>
                    <div class="photo">
                        <div class="modelPhoto">
                            <a href=""><img src="images/m16.jpg" alt=""></a>
                        </div>
                        <div class="photoName"><a href="">ERICA</a></div>
                    </div>

                </div>

            </div>

        </div>

        <div class="loadMore">
            <div class="loadMoreBtn">
                <a href="">Load More...</a>
            </div>
        </div>
        <div class="modelBanner">
            <div class="banner">
                <a href="">BECOME A MODEL</a><br><br>
                <a href="" class="applyNow">APPLY NOW</a>
            </div>

        </div>
        <div class="title">
            <h2>Model Categories</h2>
        </div>
        <div class="modelCat">
            <svg class="wave" style="transform:rotate(0deg); transition: 0.3s" viewBox="0 0 1440 100" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="sw-gradient-0" x1="0" x2="0" y1="1" y2="0"><stop stop-color="rgba(255, 192, 203, 1)" offset="0%"></stop><stop stop-color="rgba(255, 192, 203, 1)" offset="100%"></stop></linearGradient></defs><path style="transform:translate(0, 0px); opacity:1" fill="url(#sw-gradient-0)" d="M0,60L120,90L240,0L360,0L480,40L600,80L720,10L840,20L960,20L1080,80L1200,10L1320,40L1440,0L1560,10L1680,10L1800,80L1920,40L2040,50L2160,80L2280,80L2400,90L2520,0L2640,60L2760,70L2880,0L2880,100L2760,100L2640,100L2520,100L2400,100L2280,100L2160,100L2040,100L1920,100L1800,100L1680,100L1560,100L1440,100L1320,100L1200,100L1080,100L960,100L840,100L720,100L600,100L480,100L360,100L240,100L120,100L0,100Z"></path></svg>
            <div class="category">
                <div class="group">
                    <div class="proCat female">
                        <div class="details">
                            <h3>FEMALE MODEL</h3>
                            <a href="">EXPLORE PROFILES</a>
                        </div>
                        <a href=""><img src="images/d1.jpg" alt=""></a>
                    </div>
                    <div class="proCat male">
                        <div class="details">
                            <h3>MALE MODEL</h3>
                            <a href="">EXPLORE PROFILES</a>
                        </div>
                        <a href=""><img src="images/d2.jpg" alt=""></a>
                    </div>
                </div>
                <div class="group">
                    <div class="proCat cale">
                        <div class="details">
                            <h3>CELEBRITES</h3>
                            <a href="">EXPLORE PROFILES</a>
                        </div>
                        <a href=""><img src="images/d3.jpg" alt=""></a>
                    </div>
                    <div class="proCat kids">
                        <div class="details">
                            <h3>KIDS MODEL</h3>
                            <a href="">EXPLORE PROFILES</a>
                        </div>
                        <a href=""><img src="images/d4.jpg" alt=""></a>
                    </div>
                </div>


            </div>
            <svg class="waveBottom" style="transform:rotate(180deg); transition: 0.3s" viewBox="0 0 1440 100" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="sw-gradient-0" x1="0" x2="0" y1="1" y2="0"><stop stop-color="rgba(255, 192, 203, 1)" offset="0%"></stop><stop stop-color="rgba(255, 192, 203, 1)" offset="100%"></stop></linearGradient></defs><path style="transform:translate(0, 0px); opacity:1" fill="url(#sw-gradient-0)" d="M0,60L120,90L240,0L360,0L480,40L600,80L720,10L840,20L960,20L1080,80L1200,10L1320,40L1440,0L1560,10L1680,10L1800,80L1920,40L2040,50L2160,80L2280,80L2400,90L2520,0L2640,60L2760,70L2880,0L2880,100L2760,100L2640,100L2520,100L2400,100L2280,100L2160,100L2040,100L1920,100L1800,100L1680,100L1560,100L1440,100L1320,100L1200,100L1080,100L960,100L840,100L720,100L600,100L480,100L360,100L240,100L120,100L0,100Z"></path></svg>
        </div>

        <div class="title">
            <h2>Our Service</h2>
        </div>

        <div class="centerModel">
            <div class="models">
                <div class="modelCategory">
                    <a href=""><span class="icon material-symbols-sharp">
                        volume_up
                        </span><span>PROMOTTIONAL MODEL</span></a>
                    <a href=""><span class="icon material-symbols-sharp">
                        celebration
                        </span><span>EVENT MANAGEEMENT</span></a>
                    <a href=""><span class="icon material-symbols-sharp">
                        photo_camera
                        </span><span>PHOTOGRAPHY MODEL</span></a>
                    <a href=""><span class="icon material-symbols-sharp">
                        connected_tv
                        </span><span>TELEVISION MODELS</span></a>
                </div>
                <div class="modelCategory">
                    <a href=""><span class="icon material-symbols-sharp">
                        movie
                        </span><span>BRAND AMBASSADORS</span></a>
                    <a href=""><span class="icon material-symbols-sharp">
                        piano
                        </span><span>STUDIO RENTALS</span></a>
                    <a href=""><span class="icon material-symbols-sharp">
                        play_lesson
                        </span><span>RUNWAY MODELS</span></a>
                    <a href=""><span class="icon material-symbols-sharp">
                        group_add
                        </span><span>MARKETING</span></a>
                </div>
            </div>
        </div>

        <div class="aboutUs">
            <div class="title">
                <h2>About us</h2>
            </div>
            <div class="ourInfo">

                <div class="infoDetails">
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit dolor quidem blanditiis nobis inventore. Modi excepturi placeat, mollitia voluptates corrupti natus assumenda! Repudiandae odio consequuntur quis. Ex aperiam accusantium
                        tempore.Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit dolor quidem blanditiis nobis inventore. Modi excepturi placeat, mollitia voluptates corrupti natus assumenda! Repudiandae odio consequuntur quis. Ex aperiam
                        accusantium tempore.
                    </p>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit dolor quidem blanditiis nobis inventore. Modi excepturi placeat, mollitia voluptates corrupti natus assumenda! Repudiandae odio consequuntur quis. Ex aperiam accusantium
                        tempore.Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam voluptatem exercitationem quam earum labore minus nisi eum. Voluptas placeat, et natus explicabo saepe, quos fugit quaerat possimus tempore sit odit?</p>
                </div>
                <div class="infoCategory">
                    <a href=""><span class="icon material-symbols-sharp">
                        school
                        </span><span>Over 20 years experience</span></a>
                    <a href=""><span class="icon material-symbols-sharp">
                        thumb_up
                        </span><span>Professional advice</span></a>
                    <a href=""><span class="icon material-symbols-sharp">
                        emoji_events
                        </span><span>Theee best model agency in the world</span></a>

                </div>
            </div>
        </div>

        <div class="map">
            <div class="imgMap">
                <div class="address">
                    <a href=""><span class="material-symbols-sharp">
                        location_on
                        </span>
                    <span>Address</span>
                    <small>Ahemdabad</small></a>
                </div>
                <div class="address">
                    <a href=""><span class="material-symbols-sharp">
                        mail
                        </span>
                    <span>Email</span>
                    <small>xyz@gmail.com</small></a>
                </div>
                <div class="address">
                    <a href=""><span class="material-symbols-sharp">
                        smartphone
                        </span>
                    <span>Phone</span>
                    <small>+91 7203954483</small></a>
                </div>
                <div class="address">
                    <a href=""><span class="material-symbols-sharp">
                        desktop_windows
                        </span>
                    <span>Portfolio</span>
                    <small>www.modeling.info</small></a>
                </div>
            </div>
        </div>
    </main>
    <footer>

        <div class="socialMedia">
            <div class="mediaIcon">
                <a href=""><img src="images/s1.png" alt=""></a>
                <a href=""><img src="images/s2.png" alt=""></a>
                <a href=""><img src="images/s3.png" alt=""></a>
            </div>
            <div class="websiteLogo">
                <a href=""><img src="images/logo.png" alt=""></a>
            </div>
            <div class="copyRight">
                <a href="">©Copyright 2023 All Rights Reserved</a>
            </div>
        </div>
    </footer>
</body>

</html>
