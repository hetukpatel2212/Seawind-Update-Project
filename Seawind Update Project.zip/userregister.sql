-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2023 at 05:38 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loginregister`
--

-- --------------------------------------------------------

--
-- Table structure for table `userregister`
--

CREATE TABLE `userregister` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userregister`
--

INSERT INTO `userregister` (`id`, `name`, `email`, `phone`, `password`, `cpassword`) VALUES
(14, 'Hetuk', 'hetuk@gmail.com', '7203954483', '$2y$10$tlzTsm8U4mwB1OqpHt928uNfYxSeaQvXGLCPFLUwcrJjhtu85JlEW', '$2y$10$Pj1OxvF1yghQytaGGuEzreeI61O97mmwUdskbipG9Y1iVevrkxZU6'),
(15, 'd', 'e', '1', '$2y$10$OE1feH.Q8DE2yThRnpdbEOUoRpuyR6r8NibYiacH2B1OpByn.gKoe', '$2y$10$AZopH0CF3Y0P1DPvSroD..28lt/A4qKmnI/EBz2lpuICs6YY7yF7i'),
(16, '1111', 'q@gmail.com', '7203954483', '$2y$10$uD4C4nlHeRpPtQmbQCr5neraii42YW3oupFAOKCHCr573wupy7m4.', '$2y$10$H/VXjFcFuTj6ZcepW1DDsOBzaFwhiR9qJVT6.5BNKpQGtmXN0ttLe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `userregister`
--
ALTER TABLE `userregister`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `userregister`
--
ALTER TABLE `userregister`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
